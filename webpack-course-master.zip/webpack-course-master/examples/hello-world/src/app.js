console.log('hello word');

document.write('<h1>Hello World 2</h1>')
