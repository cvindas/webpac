export var toggleButton = document.querySelector('#toggle-button');
export var secretParagraph = document.querySelector('#secret-paragraph'); 
