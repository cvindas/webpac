1. npm init -y
2. npm install webpack -D
3. npm bin
4. node_modules/.bin/webpack 
5. create app/index.js
6. node_modules/.bin/webpack app/index.js build/index.js 
7. create webpack.config.js
8. install html-webpack-plugin
