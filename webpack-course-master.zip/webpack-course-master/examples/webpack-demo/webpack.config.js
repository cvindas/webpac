const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const PATHS = {
	app: path.join(__dirname,'app'),
	build: path.join(__dirname, 'build')
};

module.exports = {
	// Entries have to resolve to files! They rely on Node
	//   // convention by default so if a directory contains *index.js*,
	//     // it resolves to that.
	entry: {
		app: PATHS.app,
	},
	output: {
		path: PATHS.build,
		// [name] will be replace for the name of the entry
		filename: '[name].js',
	},
	plugins: [
		new HtmlWebpackPlugin({
			title: 'webpack demo',
		}),
	],
};
