import component from './component.js';

document.body.appendChild(component());
