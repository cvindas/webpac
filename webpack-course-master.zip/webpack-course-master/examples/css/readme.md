- [loaders](https://webpack.js.org/concepts/loaders/#components/sidebar/sidebar.jsx)

- css loader
- style loader

- node-sass
- sass loader
- [webpack-extract-text-plugin](https://github.com/webpack-contrib/extract-text-webpack-plugin)
